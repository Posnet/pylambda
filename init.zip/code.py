def handler(msg, ctx):
    return True
